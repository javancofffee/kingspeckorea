<?php
include_once('./_common.php');

// 도움말
include_once(G5_PATH.'/head.sub.php');
include_once($misc_skin_path.'/helper.php');
include_once(G5_PATH.'/tail.sub.php');

?>