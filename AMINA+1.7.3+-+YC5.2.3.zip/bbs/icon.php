<?php
include_once('./_common.php');
include_once(G5_BBS_PATH.'/ficon.php');
?>