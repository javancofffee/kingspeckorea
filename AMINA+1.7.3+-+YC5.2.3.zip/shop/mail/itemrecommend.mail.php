<?php
// 상품추천
if (!defined('_GNUBOARD_')) exit; // 개별 페이지 접근 불가

@include($misc_skin_path.'/itemrecommend.mail.php');

?>