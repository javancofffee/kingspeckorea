<?php
// 고객님께
if (!defined('_GNUBOARD_')) exit; // 개별 페이지 접근 불가

@include($misc_skin_path.'/orderupdate2.mail.php');

?>